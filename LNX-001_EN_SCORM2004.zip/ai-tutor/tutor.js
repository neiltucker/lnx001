// Courseware Studio LMS-Embedded AI Learning Assistant Widget — Universal BM25 Concept Engine
(function () {
  'use strict';

  var EN = window.__CS_AI_TUTOR_ENABLED__;
  if (EN === 0 || EN === false || EN === '0') return;
  var CFG = window.__CS_AI_TUTOR_CONFIG__ || {};

  var MAX_HISTORY_EXCHANGES = 10;
  var SS_KEY_HISTORY = 'cs_ai_tutor_history_v13';
  var SS_KEY_WELCOMED = 'cs_ai_tutor_welcomed_v13';

  // Base URL resolution
  var currentScript = document.currentScript || (function() {
    var scripts = document.getElementsByTagName('script');
    for (var i = scripts.length - 1; i >= 0; i--) {
      if (scripts[i].src && scripts[i].src.indexOf('tutor.js') !== -1) return scripts[i];
    }
    return null;
  })();
  var BASE_URL = (function() {
    if (currentScript && currentScript.src) {
      return currentScript.src.substring(0, currentScript.src.lastIndexOf('/') + 1);
    }
    return 'ai-tutor/';
  })();

  var DOM = {
    button: 'cs-tutor-button',
    panel: 'cs-tutor-panel',
    overlay: 'cs-tutor-overlay',
    title: 'cs-tutor-title',
    closeBtn: 'cs-tutor-close',
    log: 'cs-tutor-log',
    form: 'cs-tutor-form',
    input: 'cs-tutor-input',
    submit: 'cs-tutor-submit',
    status: 'cs-tutor-status',
    welcome: 'cs-tutor-welcome',
    welcomeOk: 'cs-tutor-welcome-ok'
  };

  var STRINGS = {
    english: {
      title: 'LMS-Embedded AI Learning Assistant',
      openTutor: 'Open LMS-Embedded AI Learning Assistant',
      closeTutor: 'Close LMS-Embedded AI Learning Assistant',
      askTutor: 'Ask Tutor',
      inputPlaceholder: 'Ask a question about this course...',
      inputLabel: 'Your question',
      ask: 'Ask',
      loading: 'Loading course concepts...',
      footer: 'Verify important answers with your instructor or official course materials.',
      welcomeTitle: 'Welcome to your AI Learning Assistant',
      welcomeBody: 'Ask me anything covered in this course. I am here to help you understand course concepts, frameworks, and practical workplace techniques.',
      gotIt: 'Got it',
      fromModule: 'From Module',
      outsideTopic: 'This topic is not covered in this course. The AI Tutor is designed to assist with course material only.',
      instructorReferral: 'This question touches on course topics, but this specific detail is not covered in the foundational course materials. Please consult your instructor or trainer for guidance on this topic.'
    },
    spanish: {
      title: 'Tutor de IA',
      openTutor: 'Abrir el tutor de IA',
      closeTutor: 'Cerrar el tutor de IA',
      askTutor: 'Preguntar al tutor',
      inputPlaceholder: 'Haz una pregunta sobre este curso...',
      inputLabel: 'Tu pregunta',
      ask: 'Preguntar',
      loading: 'Cargando conceptos del curso...',
      footer: 'Verifica las respuestas importantes con tu instructor o con los materiales oficiales del curso.',
      welcomeTitle: 'Bienvenido a tu tutor de IA',
      welcomeBody: 'Pregúntame sobre cualquier tema cubierto en este curso. Estoy aquí para ayudarte a comprender los conceptos, marcos y técnicas prácticas.',
      gotIt: 'Entendido',
      fromModule: 'Del módulo',
      outsideTopic: 'Este tema no está cubierto en este curso. El tutor de IA está diseñado únicamente para el contenido del curso.',
      instructorReferral: 'Esta pregunta toca temas del curso, pero este detalle específico no está cubierto en los materiales del curso. Consulta a tu instructor o formador para obtener orientación sobre este tema.'
    },
    french: {
      title: 'Tuteur IA',
      openTutor: 'Ouvrir le tuteur IA',
      closeTutor: 'Fermer le tuteur IA',
      askTutor: 'Demander au tuteur',
      inputPlaceholder: 'Posez une question sur ce cours...',
      inputLabel: 'Votre question',
      ask: 'Demander',
      loading: 'Chargement des concepts du cours...',
      footer: 'Vérifiez les réponses importantes avec votre formateur ou les supports officiels du cours.',
      welcomeTitle: 'Bienvenue dans votre tuteur IA',
      welcomeBody: 'Posez-moi des questions sur tout ce qui est couvert dans ce cours. Je suis là pour vous aider à comprendre les concepts et les méthodes.',
      gotIt: 'Compris',
      fromModule: 'Du module',
      outsideTopic: 'Ce sujet n’est pas abordé dans ce cours. Le tuteur IA est conçu uniquement pour le contenu du cours.',
      instructorReferral: 'Cette question touche à des concepts du cours, mais ce détail particulier n’est pas couvert dans les supports du cours. Veuillez consulter votre formateur pour obtenir des conseils sur ce sujet.'
    },
    german: {
      title: 'KI-Tutor',
      openTutor: 'KI-Tutor öffnen',
      closeTutor: 'KI-Tutor schließen',
      askTutor: 'Tutor fragen',
      inputPlaceholder: 'Stellen Sie eine Frage zu diesem Kurs...',
      inputLabel: 'Ihre Frage',
      ask: 'Fragen',
      loading: 'Kurskonzepte werden geladen...',
      footer: 'Prüfen Sie wichtige Antworten mit Ihrem Trainer oder den offiziellen Kursmaterialien.',
      welcomeTitle: 'Willkommen bei Ihrem KI-Tutor',
      welcomeBody: 'Fragen Sie mich zu allem, was in diesem Kurs behandelt wird. Ich helfe Ihnen gerne beim Verständnis von Kurskonzepten und Methoden.',
      gotIt: 'Verstanden',
      fromModule: 'Aus Modul',
      outsideTopic: 'Dieses Thema wird in diesem Kurs nicht behandelt. Der KI-Tutor unterstützt nur bei den Kursmaterialien.',
      instructorReferral: 'Diese Frage betrifft Kursthemen, aber dieses spezifische Detail wird in den Kursunterlagen nicht behandelt. Bitte wenden Sie sich für Unterstützung an Ihren Trainer.'
    },
    portuguese: {
      title: 'Tutor de IA',
      openTutor: 'Abrir o tutor de IA',
      closeTutor: 'Fechar o tutor de IA',
      askTutor: 'Perguntar ao tutor',
      inputPlaceholder: 'Faça uma pergunta sobre este curso...',
      inputLabel: 'Sua pergunta',
      ask: 'Perguntar',
      loading: 'Carregando conceitos do curso...',
      footer: 'Verifique respostas importantes com seu instrutor ou com os materiais oficiais do curso.',
      welcomeTitle: 'Bem-vindo ao seu tutor de IA',
      welcomeBody: 'Pergunte sobre qualquer conteúdo abordado neste curso. Estou aqui para ajudar você a entender conceitos, estruturas e técnicas.',
      gotIt: 'Entendi',
      fromModule: 'Do módulo',
      outsideTopic: 'Este tópico não é abordado neste curso. O tutor de IA é projetado apenas para o conteúdo do curso.',
      instructorReferral: 'Esta pergunta aborda tópicos do curso, mas este detalhe específico não é coberto nos materiais do curso. Consulte seu instrutor para obter orientação sobre este tópico.'
    },
    italian: {
      title: 'Tutor IA',
      openTutor: 'Apri il tutor IA',
      closeTutor: 'Chiudi il tutor IA',
      askTutor: 'Chiedi al tutor',
      inputPlaceholder: 'Fai una domanda su questo corso...',
      inputLabel: 'La tua domanda',
      ask: 'Chiedi',
      loading: 'Caricamento dei concetti del corso...',
      footer: 'Verifica le risposte importanti con il tuo istruttore o con i materiali ufficiali del corso.',
      welcomeTitle: 'Benvenuto nel tuo tutor IA',
      welcomeBody: 'Fammi domande su qualsiasi argomento trattato in questo corso. Sono qui per aiutarti a comprendere i concetti del corso e i metodi pratici.',
      gotIt: 'Capito',
      fromModule: 'Dal modulo',
      outsideTopic: 'Questo argomento non è trattato in questo corso. Il tutor IA è progettato solo per i contenuti del corso.',
      instructorReferral: 'Questa domanda tocca argomenti del corso, ma questo dettaglio specifico non è coperto nei materiali del corso. Consulta il tuo istruttore per una guida su questo argomento.'
    },
    dutch: {
      title: 'AI-tutor',
      openTutor: 'AI-tutor openen',
      closeTutor: 'AI-tutor sluiten',
      askTutor: 'Vraag tutor',
      inputPlaceholder: 'Stel een vraag over deze cursus...',
      inputLabel: 'Je vraag',
      ask: 'Vragen',
      loading: 'Cursusconcepten laden...',
      footer: 'Controleer belangrijke antwoorden met je instructeur of het officiële cursusmateriaal.',
      welcomeTitle: 'Welkom bij je AI-tutor',
      welcomeBody: 'Stel me vragen over alles wat in deze cursus wordt behandeld. Ik help je graag om concepten en methoden te begrijpen.',
      gotIt: 'Begrepen',
      fromModule: 'Uit module',
      outsideTopic: 'Dit onderwerp wordt niet behandeld in deze cursus. De AI-tutor is uitsluitend ontworpen voor cursusmateriaal.',
      instructorReferral: 'Deze vraag raakt aan cursusthema’s, maar dit specifieke detail wordt niet behandeld in het cursusmateriaal. Raadpleeg je instructeur voor begeleiding bij dit onderwerp.'
    }
  };

  function normalizeLang(v) {
    v = String(v || 'english').toLowerCase();
    if (v.startsWith('es') || v.includes('spanish')) return 'spanish';
    if (v.startsWith('fr') || v.includes('french')) return 'french';
    if (v.startsWith('de') || v.includes('german')) return 'german';
    if (v.startsWith('pt') || v.includes('portuguese')) return 'portuguese';
    if (v.startsWith('it') || v.includes('italian')) return 'italian';
    if (v.startsWith('nl') || v.includes('dutch')) return 'dutch';
    return STRINGS[v] ? v : 'english';
  }

  function getLang() {
    return normalizeLang(CFG.language || (state.bundle && state.bundle.language) || 'english');
  }

  function txt(key) {
    var lang = getLang();
    var dict = STRINGS[lang] || STRINGS.english;
    var runtime = (window.__CS_AI_TUTOR_STRINGS__ && window.__CS_AI_TUTOR_STRINGS__[lang]) || {};
    return runtime[key] || dict[key] || STRINGS.english[key] || key;
  }

  // Morphological stemmer
  function stem(w) {
    if (!w || w.length <= 2) return w;
    w = w.toLowerCase();
    if (w.endsWith('ational')) return w.slice(0, -5) + 'e';
    if (w.endsWith('tional')) return w.slice(0, -2);
    if (w.endsWith('ation')) return w.slice(0, -3) + 'e';
    if (w.endsWith('ment')) return w.slice(0, -4);
    if (w.endsWith('ness')) return w.slice(0, -4);
    if (w.endsWith('able') || w.endsWith('ible')) return w.slice(0, -4);
    if (w.endsWith('ies')) return w.slice(0, -3) + 'y';
    if (w.endsWith('ing') && w.length > 5) return w.slice(0, -3);
    if (w.endsWith('ed') && w.length > 4) return w.slice(0, -2);
    if (w.endsWith('ly') && w.length > 4) return w.slice(0, -2);
    if (w.endsWith('ic') && w.length > 4) return w.slice(0, -2);
    if (w.endsWith('al') && w.length > 4) return w.slice(0, -2);
    if (w.endsWith('es') && w.length > 4) return w.slice(0, -2);
    if (w.endsWith('s') && !w.endsWith('ss') && !w.endsWith('us') && !w.endsWith('is')) return w.slice(0, -1);
    return w;
  }

  var STOP = new Set([
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'and', 'or', 'but',
    'if', 'then', 'of', 'to', 'in', 'on', 'at', 'by', 'for', 'with', 'do', 'does', 'did',
    'have', 'has', 'had', 'what', 'which', 'who', 'when', 'where', 'why', 'how', 'this',
    'that', 'these', 'those', 'you', 'your', 'my', 'me', 'we', 'us', 'our', 'it', 'its',
    'they', 'them', 'their', 'can', 'could', 'would', 'should', 'will', 'shall', 'as',
    'from', 'about', 'into', 'than', 'so', 'not', 'nor', 'too', 'very', 'just', 'only',
    'also', 'still', 'even', 'any', 'some', 'all', 'every', 'most', 'more', 'less', 'few',
    'put', 'tell', 'show', 'give', 'make', 'use', 'using', 'used', 'uses', 'ok', 'okay',
    'one', 'two', 'three', 'four', 'part', 'parts', 'enough', 'things', 'thing', 'better',
    'best', 'list', 'specific', 'specifically',
    'explain', 'describe', 'provide', 'between', 'differ', 'different', 'difference', 'differences',
    'compare', 'comparison', 'versus', 'distinguish', 'include', 'includes', 'included', 'including', 'core',
    // Spanish
    'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'es', 'son', 'fue', 'fueron', 'de',
    'del', 'en', 'con', 'por', 'para', 'que', 'cual', 'quien', 'como', 'este', 'esta',
    // French
    'le', 'les', 'des', 'est', 'sont', 'dans', 'avec', 'pour', 'qui', 'que', 'quel', 'comment',
    // German
    'der', 'die', 'das', 'den', 'dem', 'des', 'ein', 'eine', 'ist', 'sind', 'und', 'oder', 'fuer'
  ]);

  var CONCEPT_SYNONYMS = {};

  function tokenize(text) {
    if (!text) return [];
    var words = text.toLowerCase()
      .replace(/[^a-z0-9\s-]/g, ' ')
      .split(/\s+/)
      .filter(function (w) { return w.length > 1 && !STOP.has(w); });
    return words.map(stem);
  }

  // Universal administrative & logistics deployment guard
  var LOGISTICS_REGEX = /\b(minimum hardware|hardware requirements|passing score|exam voucher|grading scale|homework deadline)\b/i;

  var state = {
    initialized: false,
    panelOpen: false,
    loadingBundle: false,
    bundleReady: false,
    bundle: null,
    history: [],
    currentModule: CFG.moduleNumber || 1,
    currentLesson: CFG.lessonTitle || null,
    docData: [],
    corpusVocab: new Map(),
    acronymAliases: {},
    fatal: null,
    returnFocus: null,
    backgroundState: [],
    bodyOverflow: null
  };

  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (k === 'class') e.className = attrs[k];
      else if (k === 'text') e.textContent = attrs[k];
      else if (k === 'href') e.setAttribute('href', attrs[k]);
      else if (k.indexOf('data-') === 0 || k.indexOf('aria-') === 0 || k === 'role' || k === 'id' || k === 'type' || k === 'name' || k === 'placeholder' || k === 'autocomplete' || k === 'tabindex' || k === 'inert') e.setAttribute(k, attrs[k]);
      else if ((k === 'disabled' || k === 'checked') && attrs[k]) e.setAttribute(k, k);
    }
    if (children) {
      if (Array.isArray(children)) {
        for (var i = 0; i < children.length; i++) if (children[i] != null) e.appendChild(children[i]);
      } else if (typeof children === 'string') e.textContent = children;
      else e.appendChild(children);
    }
    return e;
  }

  function boot() {
    if (state.initialized) return;
    state.initialized = true;
    try {
      var raw = sessionStorage.getItem(SS_KEY_HISTORY);
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.history)) state.history = parsed.history.slice(-MAX_HISTORY_EXCHANGES * 2);
      }
    } catch (e) {}
    document.addEventListener('keydown', onDialogKeydown);
    renderButton();
  }

  function renderButton() {
    if (document.getElementById(DOM.button)) return;
    var btn = el('button', {
      id: DOM.button,
      class: 'cs-tutor-fab',
      type: 'button',
      'aria-label': txt('openTutor'),
      'aria-haspopup': 'dialog',
      'aria-controls': DOM.panel,
      'aria-expanded': 'false'
    });
    btn.appendChild(el('span', { class: 'cs-tutor-fab-icon', 'aria-hidden': 'true', text: '✦' }));
    btn.appendChild(el('span', { class: 'cs-tutor-fab-label', text: txt('askTutor') }));
    btn.addEventListener('click', openPanel);
    document.body.appendChild(btn);
  }

  function renderPanel() {
    if (document.getElementById(DOM.panel)) return;
    var overlay = el('div', { id: DOM.overlay, class: 'cs-tutor-overlay', 'aria-hidden': 'true' });
    overlay.addEventListener('click', closePanel);

    var panel = el('aside', {
      id: DOM.panel,
      class: 'cs-tutor-panel',
      role: 'dialog',
      'aria-labelledby': DOM.title,
      'aria-modal': 'true',
      'aria-hidden': 'true',
      inert: ''
    });

    var header = el('header', { class: 'cs-tutor-header' });
    header.appendChild(el('h2', { id: DOM.title, class: 'cs-tutor-title', text: txt('title') }));
    var closeBtn = el('button', { id: DOM.closeBtn, class: 'cs-tutor-close', type: 'button', 'aria-label': txt('closeTutor') }, '×');
    closeBtn.addEventListener('click', closePanel);
    header.appendChild(closeBtn);
    panel.appendChild(header);

    var log = el('div', { id: DOM.log, class: 'cs-tutor-log', role: 'log', 'aria-live': 'polite', 'aria-relevant': 'additions' });
    panel.appendChild(log);

    var status = el('div', { id: DOM.status, class: 'cs-tutor-status', role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true' });
    panel.appendChild(status);

    var form = el('form', { id: DOM.form, class: 'cs-tutor-form' });
    var input = el('input', { id: DOM.input, type: 'text', class: 'cs-tutor-input', placeholder: txt('inputPlaceholder'), autocomplete: 'off', 'aria-label': txt('inputLabel') });
    var submit = el('button', { id: DOM.submit, type: 'submit', class: 'cs-tutor-submit' }, txt('ask'));
    form.appendChild(input);
    form.appendChild(submit);
    form.addEventListener('submit', onSubmit);
    panel.appendChild(form);

    var footer = el('div', { class: 'cs-tutor-footer' });
    footer.appendChild(el('span', { text: txt('footer') }));
    panel.appendChild(footer);

    document.body.appendChild(overlay);
    document.body.appendChild(panel);

    if (state.history.length === 0 && !sessionStorage.getItem(SS_KEY_WELCOMED)) renderWelcome(log);
    else {
      for (var i = 0; i < state.history.length; i++) appendMessage(log, state.history[i]);
    }
  }

  function renderWelcome(log) {
    var card = el('div', { id: DOM.welcome, class: 'cs-tutor-welcome' });
    card.appendChild(el('h3', { class: 'cs-tutor-welcome-title', text: txt('welcomeTitle') }));
    card.appendChild(el('p', { class: 'cs-tutor-welcome-body', text: txt('welcomeBody') }));
    var ok = el('button', { id: DOM.welcomeOk, class: 'cs-tutor-welcome-ok', type: 'button' }, txt('gotIt'));
    ok.addEventListener('click', function () {
      try { sessionStorage.setItem(SS_KEY_WELCOMED, '1'); } catch (e) {}
      if (card.parentNode) card.parentNode.removeChild(card);
      var input = document.getElementById(DOM.input);
      if (input && !state.fatal) input.focus();
    });
    card.appendChild(ok);
    log.appendChild(card);
  }

  function getFocusable(panel) {
    var nodes = panel.querySelectorAll('button:not([disabled]), input:not([disabled]), [href], [tabindex]:not([tabindex="-1"])');
    var out = [];
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].getAttribute('aria-hidden') !== 'true' && !nodes[i].hasAttribute('inert')) out.push(nodes[i]);
    }
    return out;
  }

  function setBackgroundModalState(active) {
    if (active) {
      state.backgroundState = [];
      state.bodyOverflow = document.body.style.overflow;
      var children = document.body.children;
      for (var i = 0; i < children.length; i++) {
        var node = children[i];
        if (node.id === DOM.panel || node.id === DOM.overlay) continue;
        state.backgroundState.push({ node: node, hadInert: node.hasAttribute('inert'), ariaHidden: node.getAttribute('aria-hidden') });
        node.setAttribute('inert', '');
        node.setAttribute('aria-hidden', 'true');
      }
      document.body.style.overflow = 'hidden';
      return;
    }
    for (var j = 0; j < state.backgroundState.length; j++) {
      var saved = state.backgroundState[j];
      if (!saved.node || !saved.node.isConnected) continue;
      if (!saved.hadInert) saved.node.removeAttribute('inert');
      if (saved.ariaHidden === null) saved.node.removeAttribute('aria-hidden');
      else saved.node.setAttribute('aria-hidden', saved.ariaHidden);
    }
    state.backgroundState = [];
    document.body.style.overflow = state.bodyOverflow === null ? '' : state.bodyOverflow;
    state.bodyOverflow = null;
  }

  function onDialogKeydown(e) {
    if (!state.panelOpen) return;
    if (e.key === 'Escape' || e.keyCode === 27) {
      e.preventDefault();
      closePanel();
      return;
    }
    if (e.key === 'Tab' || e.keyCode === 9) {
      var panel = document.getElementById(DOM.panel);
      if (!panel) return;
      var focusable = getFocusable(panel);
      if (focusable.length === 0) { e.preventDefault(); return; }
      var first = focusable[0], last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  }

  function openPanel() {
    renderPanel();
    state.returnFocus = document.activeElement;
    var panel = document.getElementById(DOM.panel);
    var overlay = document.getElementById(DOM.overlay);
    var btn = document.getElementById(DOM.button);
    if (!panel || !overlay) return;

    state.panelOpen = true;
    panel.classList.add('cs-tutor-panel--open');
    overlay.classList.add('cs-tutor-overlay--open');
    panel.removeAttribute('inert');
    panel.setAttribute('aria-hidden', 'false');
    overlay.setAttribute('aria-hidden', 'false');
    if (btn) btn.setAttribute('aria-expanded', 'true');

    setBackgroundModalState(true);

    if (!state.bundleReady && !state.loadingBundle) loadBundle();

    var input = document.getElementById(DOM.input);
    if (input && !state.fatal) input.focus();
  }

  function closePanel() {
    var panel = document.getElementById(DOM.panel);
    var overlay = document.getElementById(DOM.overlay);
    var btn = document.getElementById(DOM.button);
    if (!panel || !overlay) return;

    state.panelOpen = false;
    panel.classList.remove('cs-tutor-panel--open');
    overlay.classList.remove('cs-tutor-overlay--open');
    panel.setAttribute('inert', '');
    panel.setAttribute('aria-hidden', 'true');
    overlay.setAttribute('aria-hidden', 'true');
    if (btn) btn.setAttribute('aria-expanded', 'false');

    setBackgroundModalState(false);

    if (state.returnFocus && typeof state.returnFocus.focus === 'function') {
      state.returnFocus.focus();
    }
  }

  function setStatus(text) {
    var s = document.getElementById(DOM.status);
    if (s) s.textContent = text || '';
  }

  function setFatal(msg) {
    state.fatal = msg;
    setStatus('');
    var log = document.getElementById(DOM.log);
    if (log) {
      var err = el('div', { class: 'cs-tutor-fatal', role: 'alert', text: msg });
      log.appendChild(err);
    }
    var input = document.getElementById(DOM.input), submit = document.getElementById(DOM.submit);
    if (input) input.disabled = true;
    if (submit) submit.disabled = true;
  }

  function loadBundle() {
    state.loadingBundle = true;
    setStatus(txt('loading'));

    if (window.__CS_AI_TUTOR_DATA__) {
      state.bundle = window.__CS_AI_TUTOR_DATA__;
      initCorpus();
      return;
    }

    var bundleUrl = CFG.bundleUrl || (BASE_URL + 'tutor-data.js');
    var s = document.createElement('script');
    s.src = bundleUrl;
    s.onload = function () {
      if (window.__CS_AI_TUTOR_DATA__) {
        state.bundle = window.__CS_AI_TUTOR_DATA__;
        initCorpus();
      } else {
        setFatal('LMS-Embedded AI Learning Assistant data not available');
      }
    };
    s.onerror = function () {
      setFatal('Failed to load LMS-Embedded AI Learning Assistant knowledge base');
    };
    document.head.appendChild(s);
  }

  function initCorpus() {
    if (!state.bundle) {
      if (window.__CS_AI_TUTOR_DATA__) state.bundle = window.__CS_AI_TUTOR_DATA__;
      else return;
    }
    var concepts = state.bundle.concepts;

    // Backward-compatibility: if legacy pairs format is present and concepts is missing,
    // adapt pairs into concepts on-the-fly!
    if (!concepts || !Array.isArray(concepts)) {
      var pairs = state.bundle.pairs || [];
      concepts = [];
      for (var pi = 0; pi < pairs.length; pi++) {
        var p = pairs[pi];
        var isComp = (p.pair_type === 'distinction' || /\b(differ|versus|vs|compare|difference)\b/i.test(p.question));
        var isProc = (p.pair_type === 'procedure' || /\b(how to|steps|workflow|guide)\b/i.test(p.question));
        concepts.push({
          id: p.id || ('p_' + pi),
          module_number: p.module_number || 1,
          module_title: (state.bundle.module_titles && state.bundle.module_titles[p.module_number]) || ('Module ' + (p.module_number || 1)),
          lesson_title: p.source_lesson || '',
          section_title: (p.source_anchor && p.source_anchor.source_title) || '',
          title: p.question,
          concept_type: isComp ? 'comparison' : (isProc ? 'framework' : 'definition'),
          direct_answer: p.answer,
          structured_points: [],
          citation: p.source_lesson || ('Module ' + (p.module_number || 1)),
          keywords: [p.question].concat(p.question_variants || []),
          query_anchors: [p.question].concat(p.question_variants || [])
        });
      }
    }

    state.acronymAliases = state.bundle.acronym_aliases || {};
    state.docData = [];
    state.corpusVocab = new Map();

    for (var i = 0; i < concepts.length; i++) {
      var c = concepts[i];
      var titleTokens = tokenize(c.title || '');
      var kwTokens = tokenize((c.keywords || []).join(' '));
      var qaTokens = tokenize((c.query_anchors || []).join(' '));
      var bodyTokens = tokenize((c.direct_answer || '') + ' ' + (c.structured_points || []).join(' ') + ' ' + (c.example || ''));

      state.docData.push({
        id: c.id,
        c: c,
        titleTokens: titleTokens,
        kwTokens: kwTokens,
        qaTokens: qaTokens,
        bodyTokens: bodyTokens,
        titleSet: new Set(titleTokens),
        kwSet: new Set(kwTokens),
        qaSet: new Set(qaTokens),
        bodySet: new Set(bodyTokens),
        rawTitle: (c.title || '').toLowerCase(),
        rawCitation: (c.citation || '').toLowerCase(),
        rawKeywords: (c.keywords || []).map(function(k) { return k.toLowerCase(); }),
        rawAnchors: (c.query_anchors || []).map(function(a) { return a.toLowerCase(); }),
        allTokens: titleTokens.concat(kwTokens).concat(qaTokens).concat(bodyTokens)
      });

      var unique = new Set(titleTokens.concat(kwTokens).concat(qaTokens).concat(bodyTokens));
      unique.forEach(function (t) {
        state.corpusVocab.set(t, (state.corpusVocab.get(t) || 0) + 1);
      });
    }

    state.bundleReady = true;
    state.loadingBundle = false;
    setStatus('');
  }

  function getIdf(term) {
    var df = state.corpusVocab.get(term) || 0;
    var N = state.docData.length;
    if (df === 0) return 0;
    return Math.log(1 + (N - df + 0.5) / (df + 0.5));
  }

  function fuzzyMatchWord(word) {
    if (state.corpusVocab.has(word)) return word;
    if (word.length < 6) return null;
    var keys = state.corpusVocab.keys();
    for (var vocabWord of keys) {
      if (vocabWord.length >= 5 && Math.abs(vocabWord.length - word.length) <= 1) {
        if (vocabWord.length === word.length) {
          var diff = 0;
          for (var k = 0; k < word.length; k++) {
            if (word[k] !== vocabWord[k]) diff++;
            if (diff > 1) break;
          }
          if (diff === 1) return vocabWord;
        } else {
          var longer = vocabWord.length > word.length ? vocabWord : word;
          var shorter = vocabWord.length > word.length ? word : vocabWord;
          var diff2 = 0;
          for (var i = 0, j = 0; i < longer.length && j < shorter.length; ) {
            if (longer[i] === shorter[j]) { i++; j++; }
            else { i++; diff2++; }
          }
          if (diff2 <= 1) return vocabWord;
        }
      }
    }
    return null;
  }

  function searchConcepts(query) {
    // 1. Generic administrative or hardware deployment question referral
    if (LOGISTICS_REGEX.test(query)) {
      return { category: 'INSTRUCTOR', reason: 'Administrative or hardware deployment question' };
    }

    // Intent detection (Universal linguistic & rhetorical patterns)
    var isComparisonQuery = /\b(differ|different|difference|distinguish|versus|vs|compare|comparison|better than|which one is better|choose)\b/i.test(query) || /\b(is this|should i use|should i choose).+\b(or)\b/i.test(query);
    var isDefinitionalQuery = /\b(what is|what are|definition of|define|used for|role of|purpose of)\b/i.test(query);
    var isListRequest = /\b(list|steps|components|parts|rules|bullet|checklist)\b/i.test(query);
    var isExampleRequest = /\b(example|sample|show me how|demonstrate|instance)\b/i.test(query);
    var isCommandRequest = /\b(command|syntax|script|statement|code|query|cli|how to run|how do i run|how to execute)\b/i.test(query);
    var isNewSessionQuery = /\b(start|new|fresh|open|launch|refresh|begin|after working)\b/i.test(query) && /\b(chat|session|thread)\b/i.test(query);

    // Task-Transfer / Production Request Gating
    var isProductionRequest = !isComparisonQuery &&
                              /\b(please\s+)?(create|write|draft|build|code|calculate)\b.+(prompt|script|code|memo|formula|spreadsheet|resume)\b/i.test(query) &&
                              !/\b(example|how to|what is|can i|explain|why|should i)\b/i.test(query);

    if (isProductionRequest) {
      return {
        category: 'IN_COURSE',
        concept: state.docData[0] ? state.docData[0].c : null,
        answer: "As an in-course AI Tutor, I explain course concepts and frameworks rather than generating custom production code or personal documents.\n\nTo construct your own implementation, apply the core concepts and structured steps taught in this course.",
        score: 100.0
      };
    }

    // 2. Tokenize & Discriminative Lexical Grounding
    var rawWords = query.toLowerCase()
      .replace(/[^a-z0-9\s-]/g, ' ')
      .split(/\s+/)
      .filter(function (w) { return w.length > 1 && !STOP.has(w); });

    var totalQueryIdf = 0;
    var groundedIdf = 0;
    var correctedTokens = [];
    var expandedTokens = [];
    var N = state.docData.length;

    var discriminativeTotal = 0;
    var discriminativeGrounded = 0;

    for (var r = 0; r < rawWords.length; r++) {
      var raw = rawWords[r];
      var s = stem(raw);
      var matched = state.corpusVocab.has(s) ? s : fuzzyMatchWord(s);
      var idf = matched ? getIdf(matched) : Math.log(1 + Math.max(N, 10) * 2);
      totalQueryIdf += idf;

      var df = matched ? (state.corpusVocab.get(matched) || 0) : 0;
      var isUbiquitous = df > (N * 0.40); // Appears in >40% of concepts (generic course baseline noise)

      if (!isUbiquitous) {
        discriminativeTotal++;
        if (matched) discriminativeGrounded++;
      }

      if (matched) {
        groundedIdf += idf;
        correctedTokens.push(matched);
        expandedTokens.push(matched);
      }

      // Expand acronym aliases compiled into the course bundle
      var aliasList = state.acronymAliases && (state.acronymAliases[raw] || state.acronymAliases[s]);
      if (aliasList) {
        for (var aIdx = 0; aIdx < aliasList.length; aIdx++) {
          var aTokens = tokenize(aliasList[aIdx]);
          for (var atIdx = 0; atIdx < aTokens.length; atIdx++) {
            var atToken = aTokens[atIdx];
            expandedTokens.push(atToken);
            if (!matched && state.corpusVocab.has(atToken)) {
              matched = atToken;
              groundedIdf += getIdf(atToken);
              correctedTokens.push(atToken);
              discriminativeGrounded++;
            }
          }
        }
      }

      // Expand synonyms compiled into the course bundle
      var bundleSyns = (state.bundle && state.bundle.synonyms) || {};
      if (bundleSyns[raw] || bundleSyns[s]) {
        var synList = bundleSyns[raw] || bundleSyns[s];
        for (var si = 0; si < synList.length; si++) {
          expandedTokens.push(stem(synList[si]));
        }
      }
    }

    // Principle 1: Discriminative Lexical Grounding
    // If the query has informative words, but none of them exist in the curriculum, route to outside
    if (discriminativeTotal >= 1 && discriminativeGrounded === 0) {
      return { category: 'OUTSIDE', reason: 'Query topic is not covered in this course curriculum' };
    }

    var groundingRatio = totalQueryIdf > 0 ? (groundedIdf / totalQueryIdf) : 0;
    if (correctedTokens.length === 0 || (rawWords.length >= 2 && groundingRatio < 0.35)) {
      return { category: 'OUTSIDE', reason: 'Query terms are not grounded in the course curriculum' };
    }

    // Principle 4: Grammatical Interrogative Head Extraction ("Which <entity> ..." or "What <entity> ...")
    var whichMatch = query.match(/\b(?:which|what)\s+(?:[a-z]+\s+)?([a-z]+)\b/i);
    var interrogativeHead = whichMatch ? stem(whichMatch[1]) : null;

    // Principle 2: Dynamic Contiguous N-Gram Extraction (bigrams and trigrams)
    var ngrams = [];
    var queryWords = query.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim().split(' ');
    for (var nlen = 2; nlen <= 3; nlen++) {
      for (var nstart = 0; nstart + nlen <= queryWords.length; nstart++) {
        var wFirst = queryWords[nstart];
        var wLast = queryWords[nstart + nlen - 1];
        if (!STOP.has(wFirst) && !STOP.has(wLast)) {
          ngrams.push(queryWords.slice(nstart, nstart + nlen).join(' '));
        }
      }
    }

    // 4. Multi-Field BM25 Scoring
    var best = { idx: -1, score: 0, concept: null };
    var querySet = new Set(correctedTokens);

    for (var i = 0; i < N; i++) {
      var c = state.docData[i].c;
      var doc = state.docData[i];
      var score = 0;

      // Sublinear term scoring across fields
      querySet.forEach(function (term) {
        var termIdf = getIdf(term);
        if (doc.titleSet.has(term)) score += termIdf * 4.0;
        if (doc.kwSet.has(term)) score += termIdf * 3.0;
        if (doc.qaSet.has(term)) score += termIdf * 3.0;
        if (doc.bodySet.has(term)) score += termIdf * 1.5;
      });

      expandedTokens.forEach(function (term) {
        var termIdf = getIdf(term);
        if (doc.titleSet.has(term) || doc.kwSet.has(term)) score += termIdf * 2.0;
        else if (doc.bodySet.has(term)) score += termIdf * 1.5;
      });

      // Principle 2: Dynamic Contiguous N-Gram Phrase Boosting
      for (var ng = 0; ng < ngrams.length; ng++) {
        var phrase = ngrams[ng];
        if (doc.rawTitle && doc.rawTitle.indexOf(phrase) !== -1) score += 25.0;
        else if (doc.rawKeywords && doc.rawKeywords.some(function(k) { return k.indexOf(phrase) !== -1; })) score += 20.0;
        else if (doc.rawCitation && doc.rawCitation.indexOf(phrase) !== -1) score += 15.0;
        else if (doc.rawAnchors && doc.rawAnchors.some(function(a) { return a.indexOf(phrase) !== -1; })) score += 5.0;
      }

      // Principle 4: Interrogative Entity Head Alignment
      if (interrogativeHead && interrogativeHead.length > 2 && !STOP.has(interrogativeHead)) {
        if (doc.titleSet.has(interrogativeHead)) score += 15.0;
        else if (doc.kwSet.has(interrogativeHead)) score += 10.0;
      }

      // Intent-based alignment
      if (isComparisonQuery && c.concept_type === 'comparison') score *= 1.8;

      if (isDefinitionalQuery && c.concept_type === 'definition') score *= 1.4;
      if (isExampleRequest && c.example) score *= 2.0;

      if (isNewSessionQuery && c.polarity === 'termination') score *= 0.1;
      else if (isNewSessionQuery && c.polarity === 'initiation') score *= 2.5;

      if (score > best.score) {
        best = { idx: i, score: score, concept: c };
      }
    }

    // Principle 5: Format Presentation
    var formattedAnswer = "";
    if (best.concept) {
      if ((isExampleRequest || isCommandRequest) && best.concept.example) {
        formattedAnswer = best.concept.direct_answer + "\n\n💡 Practical Command Example / Syntax:\n" + best.concept.example;
      } else if ((isComparisonQuery || isListRequest) && best.concept.structured_points && best.concept.structured_points.length) {
        formattedAnswer = best.concept.direct_answer + "\n\n" + best.concept.structured_points.map(function(pt) {
          return "• " + pt;
        }).join("\n");
      } else {
        formattedAnswer = best.concept.direct_answer;
      }
    }

    if (best.score >= 3.5) {
      return { category: 'IN_COURSE', concept: best.concept, answer: formattedAnswer, score: best.score, isList: isListRequest };
    } else {
      return { category: 'OUTSIDE', score: best.score };
    }
  }

  function onSubmit(e) {
    e.preventDefault();
    if (state.fatal) return;

    var input = document.getElementById(DOM.input),
        query = (input.value || '').trim();
    if (!query) return;

    if (!state.bundleReady) {
      setStatus(txt('loading'));
      return;
    }

    input.value = '';
    var log = document.getElementById(DOM.log),
        w = document.getElementById(DOM.welcome);
    if (w && w.parentNode) w.parentNode.removeChild(w);

    var userMsg = { role: 'user', text: query, ts: Date.now() };
    pushHistory(userMsg);
    appendMessage(log, userMsg);

    // Immediate-Turn Horizon Dialogue Memory:
    var hasPronoun = /\b(they|them|both|these|those|which one|compare them)\b/i.test(query);
    var isShortFragment = query.split(/\s+/).length <= 3 && /\b(which|why|how|different|better|prefer|explain)\b/i.test(query);
    var isAlreadyComplete = query.split(/\s+/).length >= 5;
    var needsContext = (hasPronoun || isShortFragment) && !isAlreadyComplete;

    var effectiveQuery = query;
    if (needsContext && state.history.length > 0) {
      for (var h = state.history.length - 1; h >= 0; h--) {
        if (state.history[h].role === 'user' && state.history[h].text !== query) {
          var pTokens = tokenize(state.history[h].text);
          if (pTokens.length > 0) {
            effectiveQuery = query + ' (' + pTokens.join(' ') + ')';
          }
          break;
        }
      }
    }

    var result = searchConcepts(effectiveQuery);

    if (result.category === 'IN_COURSE' && result.concept) {
      var answerMsg = {
        role: 'assistant',
        text: result.answer,
        citation: buildCitation(result.concept),
        ts: Date.now()
      };
      pushHistory(answerMsg);
      appendMessage(log, answerMsg);
      emitAnalytics('answered', { module: state.currentModule, conceptId: result.concept.id, score: result.score });
    } else if (result.category === 'INSTRUCTOR') {
      var instructorMsg = {
        role: 'assistant',
        text: txt('instructorReferral'),
        isInstructorEscalation: true,
        queryText: query,
        ts: Date.now()
      };
      pushHistory(instructorMsg);
      appendMessage(log, instructorMsg);
      emitAnalytics('instructor_referral', { module: state.currentModule, query: query });
    } else {
      var outsideMsg = {
        role: 'assistant',
        text: txt('outsideTopic'),
        isOutsideTopic: true,
        ts: Date.now()
      };
      pushHistory(outsideMsg);
      appendMessage(log, outsideMsg);
      emitAnalytics('outside_topic', { module: state.currentModule, query: query });
    }
  }

  function buildCitation(concept) {
    if (!concept) return '';
    var modTitle = (state.bundle && state.bundle.module_titles && state.bundle.module_titles[concept.module_number]) || ('Module ' + concept.module_number);
    var cite = concept.citation || concept.lesson_title || '';
    return txt('fromModule') + ' ' + concept.module_number + ' (' + modTitle + ')' + (cite ? ' — ' + cite : '');
  }

  function pushHistory(msg) {
    state.history.push(msg);
    while (state.history.length > MAX_HISTORY_EXCHANGES * 2) state.history.shift();
    try {
      sessionStorage.setItem(SS_KEY_HISTORY, JSON.stringify({ v: 13, history: state.history }));
    } catch (e) {}
  }

  function appendMessage(log, msg) {
    if (!log) return;
    var row = el('div', { class: 'cs-tutor-msg cs-tutor-msg--' + msg.role });

    if (msg.isOutsideTopic) {
      row.appendChild(el('div', { class: 'cs-tutor-outside-card', text: msg.text }));
    } else if (msg.isInstructorEscalation) {
      var escCard = el('div', { class: 'cs-tutor-escalation-card' });
      escCard.appendChild(el('p', { class: 'cs-tutor-escalation-text', text: msg.text }));
      row.appendChild(escCard);
    } else {
      row.appendChild(el('div', { class: 'cs-tutor-msg-body', text: msg.text }));
    }

    if (msg.citation) {
      row.appendChild(el('div', { class: 'cs-tutor-msg-cite', text: msg.citation }));
    }

    log.appendChild(row);
    log.scrollTop = log.scrollHeight;
  }

  function emitAnalytics(verb, details) {
    try {
      if (typeof window.CS_xAPI_sendStatement === 'function') {
        window.CS_xAPI_sendStatement({ verb: verb, object: 'ai_tutor', details: details || {} });
      }
    } catch (e) {}
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  // Test and diagnostic hook
  try {
    window.__CS_AI_TUTOR_API__ = {
      searchConcepts: searchConcepts,
      initCorpus: initCorpus,
      tokenize: tokenize,
      state: state
    };
  } catch (e) {}
})();
